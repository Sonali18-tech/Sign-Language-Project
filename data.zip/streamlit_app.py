import streamlit as st
import cv2
import mediapipe as mp
import numpy as np
import pickle

# Load model
with open('sign_model.pkl', 'rb') as f:
    model = pickle.load(f)

# Initialize mediapipe
mp_hands = mp.solutions.hands
hands = mp_hands.Hands(static_image_mode=False, max_num_hands=1)
mp_drawing = mp.solutions.drawing_utils

# Streamlit layout
st.title("Real-Time Sign Language Recognizer")
run = st.checkbox('Start Camera')

FRAME_WINDOW = st.image([])
pred_text = st.empty()

cap = None

if run:
    cap = cv2.VideoCapture(0)
    sentence = ""

    while run:
        ret, frame = cap.read()
        if not ret:
            st.error("Failed to access webcam.")
            break

        frame = cv2.flip(frame, 1)
        rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        result = hands.process(rgb)

        if result.multi_hand_landmarks:
            for hand_landmarks in result.multi_hand_landmarks:
                mp_drawing.draw_landmarks(frame, hand_landmarks, mp_hands.HAND_CONNECTIONS)
                
                # Extract 63 features
                landmarks = []
                for lm in hand_landmarks.landmark:
                    landmarks.extend([lm.x, lm.y, lm.z])

                if len(landmarks) == 63:
                    prediction = model.predict([landmarks])[0]
                    sentence += prediction + ' '
                    pred_text.markdown(f"**Prediction:** {prediction}")

        FRAME_WINDOW.image(frame)

    cap.release()
else:
    st.warning('Check "Start Camera" to begin')
